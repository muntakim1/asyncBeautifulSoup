# asyncbs4 


[![Python](https://img.shields.io/pypi/pyversions/tensorflow.svg?style=plastic)](https://pypi.org/project/asyncbs4/1.0/)
[![PyPI](https://badge.fury.io/py/tensorflow.svg)](https://pypi.org/project/asyncbs4/1.0/)


asyncbs4 is an asynchrounous beautiful soup library which is useful for the developers to scrap file asynchrounously.

## Installation

` pip install asyncbs4`



## Usage

` from asyncbs4 import AsyncBeautifulSoup as asyncbs

url="https://facebook.com"

soup = asyncbs.get_content(url)`
