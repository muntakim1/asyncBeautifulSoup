from setuptools import setup
import setuptools
setup(name='asyncbs4',
version='1.0',
description='Asynchronous BeautifulSoup Library.',
url='https://github.com/muntakim1/asyncBeautifulSoup',
author='Muntakimur rahaman',
author_email='muntakim1104001@gmail.com',
license='MIT',
packages=setuptools.find_packages(),
zip_safe=False

)